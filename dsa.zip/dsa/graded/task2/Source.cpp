#include"Header.h"
int main() {
	RedBlackTree rbt;

	// Insert nodes into the RBT
	rbt.insert(5);
	rbt.insert(6);
	rbt.insert(3);
	rbt.insert(2);
	rbt.insert(4);
	rbt.insert(1);
	rbt.insert(8);

	// Print the height of the RBT
	cout << "Height of the Red-Black Tree: " << rbt.getHeight() << endl;

	// Remove a node from the RBT
	rbt.remove(2);

	// Print the height of the RBT after removal
	cout << "Height of the Red-Black Tree after removal: " << rbt.getHeight() << endl;

	return 0;
}


//Height of the Red-Black Tree: 3
//Height of the Red-Black Tree after removal: 3
