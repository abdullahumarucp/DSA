#include <iostream>
using namespace std;
enum Color {
	RED,
	BLACK
};

struct Node {
	int data;
	Color color;
	Node* parent;
	Node* left;
	Node* right;
};

class RedBlackTree {
private:
	Node* root;

	// Helper functions
	void rotateLeft(Node* node);
	void rotateRight(Node* node);
	void fixViolation(Node* node);
	Node* findMinimum(Node* node);
	void deleteNode(Node* node);
	int calculateHeight(Node* node);

public:
	RedBlackTree() : root(nullptr) {}
	void insert(int value);
	void remove(int value);
	int getHeight();
};

// Calculate the height of the RBT
int calculateHeight(Node* node)
{
	if (node == NULL)
		return 0;
	else {
		int lDepth = calculateHeight(node->left);
		int rDepth = calculateHeight(node->right);
		if (lDepth > rDepth)
			return (lDepth + 1);
		else
			return (rDepth + 1);
	}
}


// Get the height of the RBT
int RedBlackTree::getHeight() {
	return calculateHeight(root);
}


// Rotate the tree left around the given node
void RedBlackTree::rotateLeft(Node* node) {
	Node* rightChild = node->right;
	node->right = rightChild->left;
	if (rightChild->left != nullptr) {
		rightChild->left->parent = node;
	}
	rightChild->parent = node->parent;
	if (node->parent == nullptr) {
		root = rightChild;
	}
	else if (node == node->parent->left) {
		node->parent->left = rightChild;
	}
	else {
		node->parent->right = rightChild;
	}
	rightChild->left = node;
	node->parent = rightChild;
}

// Rotate the tree right around the given node
void RedBlackTree::rotateRight(Node* node) {
	Node* leftChild = node->left;
	node->left = leftChild->right;
	if (leftChild->right != nullptr) {
		leftChild->right->parent = node;
	}
	leftChild->parent = node->parent;
	if (node->parent == nullptr) {
		root = leftChild;
	}
	else if (node == node->parent->left) {
		node->parent->left = leftChild;
	}
	else {
		node->parent->right = leftChild;
	}
	leftChild->right = node;
	node->parent = leftChild;
}

// Fix violations in the tree after insertion
void RedBlackTree::fixViolation(Node* node) {
	while (node != root && node->parent->color == RED) {
		Node* parent = node->parent;
		Node* grandparent = parent->parent;
		if (parent == grandparent->left) {
			Node* uncle = grandparent->right;
			if (uncle != nullptr && uncle->color == RED) {
				parent->color = BLACK;
				uncle->color = BLACK;
				grandparent->color = RED;
				node = grandparent;
			}
			else {
				if (node == parent->right) {
					node = parent;
					rotateLeft(node);
					parent = node->parent;
				}
				parent->color = BLACK;
				grandparent->color = RED;
				rotateRight(grandparent);
			}
		}
		else {
			Node* uncle = grandparent->left;
			if (uncle != nullptr && uncle->color == RED) {
				parent->color = BLACK;
				uncle->color = BLACK;
				grandparent->color = RED;
				node = grandparent;
			}
			else {
				if (node == parent->left) {
					node = parent;
					rotateRight(node);
					parent = node->parent;
				}
				parent->color = BLACK;
				grandparent->color = RED;
				rotateLeft(grandparent);
			}
		}
	}
	root->color = BLACK;
}

// Insert a node with the given value into the RBT
void RedBlackTree::insert(int value) {
	Node* newNode = new Node();
	newNode->data = value;
	newNode->color = RED;
	newNode->left = nullptr;
	newNode->right = nullptr;

	if (root == nullptr) {
		newNode->color = BLACK;
		root = newNode;
		return;
	}

	Node* current = root;
	Node* parent = nullptr;
	while (current != nullptr) {
		parent = current;
		if (newNode->data < current->data) {
			current = current->left;
		}
		else {
			current = current->right;
		}
	}

	newNode->parent = parent;
	if (newNode->data < parent->data) {
		parent->left = newNode;
	}
	else {
		parent->right = newNode;
	}

	fixViolation(newNode);
}

// Find the node with the minimum value in the tree
Node* RedBlackTree::findMinimum(Node* node) {
	while (node->left != nullptr) {
		node = node->left;
	}
	return node;
}

// Delete a node from the RBT
void RedBlackTree::deleteNode(Node* node) {
	Node* successor = nullptr;
	Node* child = nullptr;
	if (node->left == nullptr || node->right == nullptr) {
		successor = node;
	}
	else {
		successor = node->right;
		while (successor->left != nullptr) {
			successor = successor->left;
		}
	}

	if (successor->left != nullptr) {
		child = successor->left;
	}
	else {
		child = successor->right;
	}

	if (child != nullptr) {
		child->parent = successor->parent;
	}

	if (successor->parent == nullptr) {
		root = child;
	}
	else if (successor == successor->parent->left) {
		successor->parent->left = child;
	}
	else {
		successor->parent->right = child;
	}

	if (successor != node) {
		node->data = successor->data;
	}

	if (successor->color == BLACK) {
		fixViolation(child);
	}

	delete successor;
}

// Remove a node with the given value from the RBT
void RedBlackTree::remove(int value) {
	if (root == nullptr) {
		return;
	}

	Node* current = root;
	while (current != nullptr) {
		if (value < current->data) {
			current = current->left;
		}
		else if (value > current->data) {
			current = current->right;
		}
		else {
			deleteNode(current);
			return;
		}
	}
}




