#include <iostream>

using namespace std;

// Node structure for BST
struct Node {
	int data;
	Node* left;
	Node* right;
};

// Function to create a new node
Node* createNode(int value) {
	Node* newNode = new Node();
	if (!newNode) {
		cout << "Memory error\n";
		return NULL;
	}
	newNode->data = value;
	newNode->left = newNode->right = NULL;
	return newNode;
}

// Function to insert a node into the BST
Node* insertNode(Node* root, int value) {
	if (root == NULL) {
		return createNode(value);
	}
	if (value < root->data) {
		root->left = insertNode(root->left, value);
	}
	else if (value > root->data) {
		root->right = insertNode(root->right, value);
	}
	return root;
}

// Function to delete a node from the BST
Node* deleteNode(Node* root, int value) {
	if (root == NULL) {
		return root;
	}
	if (value < root->data) {
		root->left = deleteNode(root->left, value);
	}
	else if (value > root->data) {
		root->right = deleteNode(root->right, value);
	}
	else {
		if (root->left == NULL) {
			Node* temp = root->right;
			delete root;
			return temp;
		}
		else if (root->right == NULL) {
			Node* temp = root->left;
			delete root;
			return temp;
		}
		Node* temp = root->right;
		while (temp->left != NULL) {
			temp = temp->left;
		}
		root->data = temp->data;
		root->right = deleteNode(root->right, temp->data);
	}
	return root;
}

// Function to search for a node in the BST
Node* searchNode(Node* root, int value) {
	if (root == NULL || root->data == value) {
		return root;
	}
	if (value < root->data) {
		return searchNode(root->left, value);
	}
	return searchNode(root->right, value);
}

// Function to count the number of nodes in the BST
int countNodes(Node* root) {
	if (root == NULL) {
		return 0;
	}
	return countNodes(root->left) + countNodes(root->right) + 1;
}

// Function to find the minimum value in the BST
int findMinValue(Node* root) {
	if (root == NULL) {
		cout << "Error: Tree is empty\n";
		return -1;
	}
	while (root->left != NULL) {
		root = root->left;
	}
	return root->data;
}

// Function to find the maximum value in the BST
int findMaxValue(Node* root) {
	if (root == NULL) {
		cout << "Error: Tree is empty\n";
		return -1;
	}
	while (root->right != NULL) {
		root = root->right;
	}
	return root->data;
}

// Function for in-order traversal of the BST
void inOrderTraversal(Node* root) {
	if (root == NULL) {
		return;
	}
	inOrderTraversal(root->left);
	cout << root->data << " ";
	inOrderTraversal(root->right);
}

// Function to calculate the height of the BST
int calculateHeight(Node* node)
{
	if (node == NULL)
		return 0;
	else {
		/* compute the depth of each subtree */
		int lDepth = calculateHeight(node->left);
		int rDepth = calculateHeight(node->right);

		/* use the larger one */
		if (lDepth > rDepth)
			return (lDepth + 1);
		else
			return (rDepth + 1);
	}
}


// Function to check if the BST is balanced
bool isBalanced(Node* root) {
	if (root == NULL) {
		return true;
	}
	int leftHeight = calculateHeight(root->left);
	int rightHeight = calculateHeight(root->right);
	int heightDiff = abs(leftHeight - rightHeight);
	if (heightDiff <= 1 && isBalanced(root->left) && isBalanced(root->right)) {
		return true;
	}
	return false;
}

