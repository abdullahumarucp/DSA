#include"Header.h"

int main() {
	Node* root = NULL;

	// Inserting nodes into the BST
	root = insertNode(root, 1);
	root = insertNode(root, 2);
	root = insertNode(root, 3);
	root = insertNode(root, 4);
	root = insertNode(root, 6);
	root = insertNode(root, 3);
	root = insertNode(root, 2);
	root = insertNode(root, 9);
	root = insertNode(root, 1);

	cout << "In-order traversal of the BST: ";
	inOrderTraversal(root);
	cout << endl;

	// Deleting a node from the BST
	root = deleteNode(root, 2);
	cout << "In-order traversal after deleting 2: ";
	inOrderTraversal(root);
	cout << endl;

	// Searching for a node in the BST
	int value = 9;
	Node* searchResult = searchNode(root, value);
	if (searchResult != NULL) {
		cout << value << " found in the BST\n";
	}
	else {
		cout << value << " not found in the BST\n";
	}

	// Counting the number of nodes in the BST
	int numNodes = countNodes(root);
	cout << "Number of nodes in the BST: " << numNodes << endl;

	// Finding the minimum and maximum values in the BST
	int minValue = findMinValue(root);
	cout << "Minimum value in the BST: " << minValue << endl;
	int maxValue = findMaxValue(root);
	cout << "Maximum value in the BST: " << maxValue << endl;

	// Calculating the height of the BST
	int height = calculateHeight(root);
	cout << "Height of the BST: " << height << endl;

	// Checking if the BST is balanced
	bool balanced = isBalanced(root);
	if (balanced) {
		cout << "BST is balanced\n";
	}
	else {
		cout << "BST is not balanced\n";
	}
	
	return 0;
}
