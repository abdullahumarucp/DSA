#include <iostream>
#include <string>
using namespace std;

template <class T>
class Stack
{
private:
	T* arr;
	int top;
	int capacity;
public:
	Stack(int size = 100)
	{
		arr = new T[size];
		capacity = size;
		top = -1;
	}
	~Stack()
	{
		delete[] arr;
	}
	void push(T x)
	{
		if (isFull())
		{
			cout << "Stack Overflow\n";
			return;
		}
		arr[++top] = x;
	}
	T pop() 
	{
		if (isEmpty())
		{
			cout << "Stack Underflow\n";
			return T();
		}
		return arr[top--];
	}
	T peek() 
	{
		if (isEmpty()) 
		{
			cout << "Stack is empty\n";
			return T();
		}
		return arr[top];
	}
	bool isEmpty() 
	{
		return top == -1;
	}
	bool isFull()
	{
		return top == capacity - 1;
	}

};

int checkFunction(char c)
{
	if (c == '*' || c == '/') 
	{
		return 2;
	}
	else if (c == '+' || c == '-') 
	{
		return 1;
	}
	else if (c == '^')
	{
		return 3;
	}
	else
	{
		return 0;
	}
}


string conversion(string expression) 
{
	Stack<char> stack;
	string postfix = " ";

	for (int i = 0; i < expression.length(); i++)
	{
		char c = expression[i];

		if (isalnum(c))
		{
			postfix += c;
		}

		else if ((c >= 'a' && c <= 'z') || (c >= 'A' && c <= 'Z') || (c >= '0' && c <= '9'))
		{
				postfix += c;
		}
	
		else if (c == '(')
		{
			stack.push(c);
		}
		else if (c == ')')
		{
			while (!stack.isEmpty() && stack.peek() != '(') 
			{
				postfix += stack.pop();
			}
			if (!stack.isEmpty() && stack.peek() == '(')
			{
				stack.pop();
			}
		}
		else
		{
			while (!stack.isEmpty() && checkFunction(c) <= checkFunction(stack.peek())) 
			{
				postfix += stack.pop();
			}
			stack.push(c);
		}
	}

	while (!stack.isEmpty()) 
	{
		postfix += stack.pop();
	}

	return postfix;
}


int main()
{
	string infixExpression;
	cout << "Enter an infix expression: ";
	getline(cin, infixExpression);

	string postfixExpression =  conversion(infixExpression);
	cout << "Postfix expression: " << postfixExpression << endl;

	return 0;
}
