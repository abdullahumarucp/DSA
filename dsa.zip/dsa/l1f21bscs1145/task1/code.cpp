#include<iostream>
#include<fstream>
using namespace std;
const int range = 100;
int maze[range][range];

class Stack
{
	int data[range*range];
	int top;
public:
	Stack()
	{
		top = -1;
	}
	void push(int x_axis, int y_axis){
		if (top == (range*range) - 1){
			cout << "STACK OVERFLOW!\n";
			return;
		}
		top++;
		data[top] = x_axis *range + y_axis;
	}
	void pop(){
		if (top == -1){
			cout << "STACK UNDERFLOW!\n";
			return;
		}
		top--;
	}
	int peek_x_axis(){
		if (top == -1){
			cout << "STACK UNDERFLOW!\n";
			return -1;
		}
		return data[top] / range;
	}
	int peek_y_axis(){
		if (top == -1){
			cout << "STACK UNDERFLOW!\n";
			return -1;
		}
		return data[top] % range;
	}
	bool empty(){
		return (top == -1);
	}
};

bool tracking_maze(int n, ofstream& outfile){
	Stack s;
	s.push(0, 0);
	while (!s.empty()){
		int x = s.peek_x_axis();
		int y = s.peek_y_axis();
		s.pop();
		if (x == n - 1 && y == n - 1){
			for (int i = 0; i<n; i++){
				for (int j = 0; j<n; j++){
					if (maze[i][j] == -1)
						outfile << "1 ";
					else
						outfile << "0 ";
				}
				outfile << endl;
			}
			return true;
		}
		maze[x][y] = -1;
		if (x>0 && maze[x - 1][y] == 1)
			s.push(x - 1, y);
		if (x<n - 1 && maze[x + 1][y] == 1)
			s.push(x + 1, y);
		if (y>0 && maze[x][y - 1] == 1)
			s.push(x, y - 1);
		if (y< n - 1 && maze[x][y + 1] == 1)
			s.push(x, y + 1);
	}
	return false;
}
int main() {
	ifstream infile("input.txt");
	ofstream outfile("output.txt");

	int n;
	infile >> n;
	for (int i = 0; i < n; i++) {
		for (int j = 0; j < n; j++) {
			infile >> maze[i][j];
		}
	}

	if (tracking_maze(n, outfile))
		cout << "Path found!!!" << endl;
	else
		outfile << "PATH NOT FOUND" << endl;

	infile.close();
	outfile.close();
	return 0;
}