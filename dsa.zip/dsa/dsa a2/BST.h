#ifndef BST_H
#define BST_H
#include <iostream>
using namespace std;

template <typename T>
class Node {
public:
    T item;
    int count;
    Node<T>* left;
    Node<T>* right;

    Node(T value) : item(value), count(1), left(nullptr), right(nullptr) {}
};

template <typename T>
class BST {
private:
    Node<T>* root;

    Node<T>* get_successor(Node<T>* root) {
        if (root->left == nullptr) {
            return root;
        }
        return get_successor(root->left);
    }

    Node<T>* insert_node(Node<T>* root, T value) {
        if (root == nullptr) {
            return new Node<T>(value);
        }
        if (value < root->item) {
            root->left = insert_node(root->left, value);
        }
        else if (value > root->item) {
            root->right = insert_node(root->right, value);
        }
        else {
            root->count++;
        }
        return root;
    }

    Node<T>* delete_node(Node<T>* root, T value) {
        if (root == nullptr) {
            cout << "\nValue not found in the tree\n";
            return nullptr;
        }
        if (value < root->item) {
            root->left = delete_node(root->left, value);
        }
        else if (value > root->item) {
            root->right = delete_node(root->right, value);
        }
        else {
            if (root->count > 1) {
                root->count--;
            }
            else {
                if (root->left == nullptr && root->right == nullptr) {
                    delete root;
                    root = nullptr;
                }
                else if (root->left == nullptr) {
                    Node<T>* temp = root;
                    root = root->right;
                    delete temp;
                }
                else if (root->right == nullptr) {
                    Node<T>* temp = root;
                    root = root->left;
                    delete temp;
                }
                else {
                    Node<T>* successor = get_successor(root->right);
                    root->item = successor->item;
                    root->count = successor->count;
                    root->right = delete_node(root->right, successor->item);
                }
                cout << "\nValue Deleted successfully\n";
            }
        }
        return root;
    }

public:
    BST() : root(nullptr) {}

    void delete_(T value) {
        root = delete_node(root, value);
    }

    void insert(T value) {
        root = insert_node(root, value);
    }

    int count(Node<T>* root, T value) {
        if (root == nullptr) {
            return 0;
        }
        if (value < root->item) {
            return count(root->left, value);
        }
        else if (value > root->item) {
            return count(root->right, value);
        }
        else {
            return root->count;
        }
    }

    bool searchtree(Node<T>* root, T value, int& comparisons, int& level, int tlev) {
        if (root == nullptr) {
            comparisons = tlev;
            level = -1;
            return false;
        }
        if (value < root->item) {
            return searchtree(root->left, value, comparisons, level, tlev + 1);
        }
        else if (value > root->item) {
            return searchtree(root->right, value, comparisons, level, tlev + 1);
        }
        else {
            comparisons = tlev;
            level = tlev;
            return true;
        }
    }

    void inorder_traversal(Node<T>* root) {
        if (root == nullptr) {
            return;
        }
        inorder_traversal(root->left);
        cout << root->item << "(" << root->count << "), ";
        inorder_traversal(root->right);
    }

    void delete_tree(Node<T>* root) {
        if (root == nullptr) {
            return;
        }
        delete_tree(root->left);
        delete_tree(root->right);
        delete root;
    }

    ~BST() {
        delete_tree(root);
    }
    Node<T>* get_root(){
        return this->root;
    }
};
#endif
