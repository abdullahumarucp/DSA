#include<iostream>
#include "BST.h"
using namespace std;
int main() {
    BST<int> bst;
    int choice, value;

    do {
        cout << "------ Binary Search Tree Menu ------" << endl;
        cout << "1. Insert value" << endl;
        cout << "2. Delete value" << endl;
        cout << "3. Search for value" << endl;
        cout << "4. Print tree (In-order traversal)" << endl;
        cout << "5. Exit" << endl;
        cout << "Enter your choice: ";
        cin >> choice;

        switch (choice) {
            case 1:
                cout << "Enter value to insert: ";
                cin >> value;
                bst.insert(value);
                cout << "Value inserted successfully!" << endl;
                break;

            case 2:
                cout << "Enter value to delete: ";
                cin >> value;
                bst.delete_(value);
                break;

            case 3:
                cout << "Enter value to search: ";
                cin >> value;
                int comparisons, level;
                if (bst.searchtree(bst.get_root(), value, comparisons, level, 0)) {
                    cout << "Value found in the tree." << endl;
                    cout << "Comparisons made: " << comparisons << endl;
                    cout << "Level of the node: " << level << endl;
                } else {
                    cout << "Value not found in the tree." << endl;
                    cout << "Comparisons made: " << comparisons << endl;
                }
                break;

            case 4:
                cout << "Tree (In-order traversal): ";
                bst.inorder_traversal(bst.get_root());
                cout << endl;
                break;

            case 5:
                cout << "Exiting the program..." << endl;
                break;

            default:
                cout << "Invalid choice. Please try again." << endl;
        }

        cout << endl;

    } while (choice != 5);

    return 0;
}